Sakshi's Birthday Surprise
index.html, style.css, script.js
images/photo1.jpg, photo2.jpg, photo3.jpg  (replace to change photos, same file names)
music/song.mp3 (optional: add your own song with exactly this name)
