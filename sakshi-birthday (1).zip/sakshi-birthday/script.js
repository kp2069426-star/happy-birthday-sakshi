(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var heartsBox = $('#hearts'), heartTimer = null;

  /* ---------- floating hearts ---------- */
  var glyphs = ['💗', '💖', '🌷', '🎀', '✨', '🌸', '💕'];
  function heart() {
    var h = document.createElement('span');
    h.className = 'fh';
    h.textContent = glyphs[Math.floor(Math.random() * glyphs.length)];
    h.style.left = Math.random() * 100 + 'vw';
    h.style.fontSize = 14 + Math.random() * 26 + 'px';
    h.style.animationDuration = 6 + Math.random() * 6 + 's';
    heartsBox.appendChild(h);
    setTimeout(function () { h.remove(); }, 12500);
  }
  function startHearts(ms) {
    clearInterval(heartTimer);
    heartTimer = setInterval(heart, ms);
  }

  /* ---------- confetti ---------- */
  var cv = $('#confetti'), cx = cv.getContext('2d'), bits = [], raf = null;
  function size() { cv.width = innerWidth; cv.height = innerHeight; }
  addEventListener('resize', size); size();
  var cols = ['#ff6fa5', '#ffb3cf', '#ffd98a', '#fff', '#c2185b', '#ff9fc2'];
  function confetti(n) {
    for (var i = 0; i < n; i++) {
      bits.push({ x: Math.random() * cv.width, y: -20 - Math.random() * cv.height * 0.4,
        w: 6 + Math.random() * 6, h: 8 + Math.random() * 8, vy: 2 + Math.random() * 3,
        vx: -1.5 + Math.random() * 3, r: Math.random() * 6, vr: -.2 + Math.random() * .4,
        c: cols[Math.floor(Math.random() * cols.length)] });
    }
    if (!raf) loop();
  }
  function loop() {
    cx.clearRect(0, 0, cv.width, cv.height);
    bits = bits.filter(function (b) { return b.y < cv.height + 30; });
    bits.forEach(function (b) {
      b.x += b.vx; b.y += b.vy; b.r += b.vr;
      cx.save(); cx.translate(b.x, b.y); cx.rotate(b.r);
      cx.fillStyle = b.c; cx.fillRect(-b.w / 2, -b.h / 2, b.w, b.h); cx.restore();
    });
    raf = bits.length ? requestAnimationFrame(loop) : null;
    if (!bits.length) cx.clearRect(0, 0, cv.width, cv.height);
  }

  /* ---------- screens ---------- */
  function go(id) {
    $$('.screen').forEach(function (s) { s.classList.remove('on'); });
    var t = document.getElementById(id);
    t.classList.add('on');
    scrollTo(0, 0);
    if (id === 'birthday') { confetti(160); setTimeout(function () { confetti(100); }, 1500); startHearts(350); }
    else if (id === 'final') { startHearts(160); confetti(120); setTimeout(function () { confetti(120); }, 1800); }
    else startHearts(900);
  }
  $$('[data-go]').forEach(function (b) {
    b.addEventListener('click', function () { go(b.getAttribute('data-go')); });
  });

  /* ---------- cake ---------- */
  var blown = false;
  $('#blowBtn').addEventListener('click', function () {
    if (blown) return;
    blown = true;
    $$('.candle').forEach(function (c, i) { setTimeout(function () { c.classList.add('out'); }, i * 250); });
    setTimeout(function () {
      $('#cakeBox').classList.add('blown');
      $('#cakeMsg').textContent = 'Your wish is on its way, Madam Ji 💗';
      confetti(180);
      $('#blowBtn').classList.add('hidden');
      $('#cakeNext').classList.remove('hidden');
    }, 900);
  });

  /* ---------- gallery lightbox ---------- */
  var lb = $('#lightbox');
  $$('.frame').forEach(function (f) {
    f.addEventListener('click', function () {
      $('img', lb).src = $('img', f).src; lb.classList.remove('hidden');
    });
  });
  lb.addEventListener('click', function () { lb.classList.add('hidden'); });
  addEventListener('keydown', function (e) { if (e.key === 'Escape') lb.classList.add('hidden'); });

  /* ---------- envelope ---------- */
  $('#envelope').addEventListener('click', function () {
    this.classList.add('open');
    $('#envHint').classList.add('hidden');
    setTimeout(function () {
      var l = $('#letterText'); l.classList.remove('hidden');
      l.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 1100);
  });

  /* ---------- replay ---------- */
  $('#replay').addEventListener('click', function () {
    blown = false;
    $$('.candle').forEach(function (c) { c.classList.remove('out'); });
    $('#cakeBox').classList.remove('blown');
    $('#cakeMsg').textContent = 'Close your eyes, make a wish, then blow out the candles.';
    $('#blowBtn').classList.remove('hidden'); $('#cakeNext').classList.add('hidden');
    $('#envelope').classList.remove('open'); $('#envHint').classList.remove('hidden');
    $('#letterText').classList.add('hidden');
    go('welcome');
  });

  /* ---------- music (never autoplays) ---------- */
  /* Put your own song at music/song.mp3 to use it. If missing, a soft
     music-box "Happy Birthday" tune is played instead. */
  var mBtn = $('#musicBtn'), playing = false, audio = null, useSynth = false;
  var ac = null, seqTimer = null;
  try { audio = new Audio('music/song.mp3'); audio.loop = true; audio.addEventListener('error', function () { useSynth = true; }); } catch (e) { useSynth = true; }
  // [note semitones from C5, beats]
  var tune = [[0,.75],[0,.25],[2,1],[0,1],[5,1],[4,2],[0,.75],[0,.25],[2,1],[0,1],[7,1],[5,2],
              [0,.75],[0,.25],[12,1],[9,1],[5,1],[4,1],[2,2],[10,.75],[10,.25],[9,1],[5,1],[7,1],[5,2.5]];
  function tone(semi, when, dur) {
    var o = ac.createOscillator(), g = ac.createGain();
    o.type = 'sine'; o.frequency.value = 523.25 * Math.pow(2, semi / 12);
    g.gain.setValueAtTime(0, when); g.gain.linearRampToValueAtTime(.12, when + .02);
    g.gain.exponentialRampToValueAtTime(.0001, when + dur + .6);
    o.connect(g); g.connect(ac.destination); o.start(when); o.stop(when + dur + .7);
  }
  function playSeq() {
    var t = ac.currentTime + .1, beat = .55;
    tune.forEach(function (n) { tone(n[0], t, n[1] * beat); t += n[1] * beat; });
    seqTimer = setTimeout(playSeq, (t - ac.currentTime + 1.2) * 1000);
  }
  function startSynth() {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    ac = ac || new AC(); if (ac.resume) ac.resume(); playSeq(); return true;
  }
  function setBtn() {
    $('span', mBtn).textContent = playing ? 'Music on' : 'Music off';
    mBtn.setAttribute('aria-label', playing ? 'Pause music' : 'Play music');
  }
  function stopAll() {
    if (audio) audio.pause();
    clearTimeout(seqTimer); if (ac && ac.suspend) ac.suspend();
  }
  mBtn.addEventListener('click', function () {
    if (playing) { stopAll(); playing = false; setBtn(); return; }
    function synth() { useSynth = true; playing = startSynth(); setBtn(); }
    if (useSynth || !audio) { synth(); return; }
    var p = audio.play();
    if (p && p.then) p.then(function () { playing = true; setBtn(); }).catch(synth);
    else { playing = true; setBtn(); }
    playing = true; setBtn();
  });

  /* ---------- opening ---------- */
  window.addEventListener('load', function () {
    setTimeout(function () {
      $('#loader').classList.add('gone');
      mBtn.hidden = false;
      go('welcome');
    }, 1600);
  });
})();
